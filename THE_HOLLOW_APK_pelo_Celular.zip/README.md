# THE HOLLOW — O Sinal do Abismo

Jogo 3D em Three.js preparado para empacotamento Android com Capacitor.

Leia `BUILD_APK_PELO_CELULAR.txt` para gerar o APK usando GitHub Actions, sem PC ou Android Studio no celular.

Build inicial: cenário-base, câmera em primeira pessoa, controles touch, movimento, corrida, agachamento, lanterna e colisões básicas. Ainda não é o jogo completo descrito no conceito.
